#pragma once
#include <iostream>
#include <Windows.h>
#include <WinInet.h>
#include <regex>
#include "base64.h"
#include "internet.h"
#include "json.hpp"
#include "execute.h"

using namespace std;
using namespace json;